package com.netzme.controller;

public class ResultAction {

}
