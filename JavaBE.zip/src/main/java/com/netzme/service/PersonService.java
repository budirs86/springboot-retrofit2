package com.netzme.service;

import com.netzme.dto.PersonDTO;

public interface PersonService {

    PersonDTO getPerson(PersonDTO personDTO);

    PersonDTO getPerson();
}

