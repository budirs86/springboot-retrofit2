package com.netzme.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PersonDTO {

    private String gender;

    private String fullname;

    private String address;

    private String picture;
}
